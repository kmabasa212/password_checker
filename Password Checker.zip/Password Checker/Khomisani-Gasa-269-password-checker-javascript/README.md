Password strength checker (269)
For raw project instructions see: http://syllabus.africacode.net/projects/tdd/password-checker/part1/