function passwordStrength(password) {
  if (!password || password.length <= 8) {
    return "invalid";
  }

  const conditions = [
    /[a-z]/.test(password),
    /[A-Z]/.test(password),
    /[0-9]/.test(password),
    /[^a-zA-Z0-9\s]/.test(password),
    /\s/.test(password),
  ];

  const numConditionsMet = conditions.filter(Boolean).length + 2;

  if (numConditionsMet >= 6) return "strong";
  if (numConditionsMet >= 4) return "medium";
  if (numConditionsMet === 3) return "weak";

  return "invalid";
}

module.exports = { passwordStrength };
