const { passwordStrength } = require("../src/password_checker");

describe("Password Strength Checker", () => {
  it("should return invalid for empty password", () => {
    expect(passwordStrength("")).toBe("invalid");
  });

  it("should return invalid for password <= 8 characters", () => {
    expect(passwordStrength("P@ssw 12")).toBe("invalid");
    expect(passwordStrength("User1@")).toBe("invalid");
  });

  it("should return weak for password with only 3 total conditions met", () => {
    expect(passwordStrength("lowercasea")).toBe("weak");
  });

  it("should return medium for password with 4 or 5 total conditions met", () => {
    expect(passwordStrength("UserName1")).toBe("medium");

    expect(passwordStrength("User Name")).toBe("medium");
  });

  it("should return strong for password with 6 or 7 total conditions met", () => {
    expect(passwordStrength("Passw0rd!")).toBe("strong");

    expect(passwordStrength("P@ssw 123")).toBe("strong");
  });

  it("should still be invalid if first two conditions are not met", () => {
    expect(passwordStrength(" ")).toBe("invalid");
  });
});
